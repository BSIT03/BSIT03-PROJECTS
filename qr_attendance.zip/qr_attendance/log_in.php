<?php
session_start();
include 'db_connection.php';

// Hardcoded admin credentials
$admin_username = "admin";
$admin_password = "admin123";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_type = $_POST['user_type']; // Get selected user type

    if ($user_type == "admin") {
        // Admin login
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        if ($username === $admin_username && $password === $admin_password) {
            $_SESSION['role'] = "admin";
            header("Location: dashboard.php");
            exit();
        } else {
            echo "<script>alert('Invalid Admin credentials!'); window.location.href='login.php';</script>";
        }
    } elseif ($user_type == "teacher") {
        // Teacher login
        $id_number = trim($_POST['id_number']);
        $name = trim($_POST['name']);

        $stmt = $conn->prepare("SELECT * FROM teachers WHERE id_number = ? AND name = ?");
        $stmt->bind_param("is", $id_number, $name);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $teacher = $result->fetch_assoc();
            $_SESSION['id_number'] = $teacher['id_number'];
            $_SESSION['name'] = $teacher['name'];
            $_SESSION['grade_level'] = $teacher['grade_level'];
            $_SESSION['section'] = $teacher['section'];
            $_SESSION['strand'] = $teacher['strand'];

            header("Location: teacher_dashboard.php");
            exit();
        } else {
            echo "<script>alert('Invalid Teacher credentials!'); window.location.href='login.php';</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 350px;
            text-align: center;
        }
        .school-logo {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }
        .school-name {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 20px;
        }
        h2 {
            margin-bottom: 20px;
        }
        select, input, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background: #0056b3;
        }
    </style>
    <script>
        function toggleFields() {
            var userType = document.getElementById("user_type").value;
            if (userType === "admin") {
                document.getElementById("adminFields").style.display = "block";
                document.getElementById("teacherFields").style.display = "none";
            } else if (userType === "teacher") {
                document.getElementById("adminFields").style.display = "none";
                document.getElementById("teacherFields").style.display = "block";
            }
        }
    </script>
</head>
<body>
    <div class="login-container">
        <img src="school_logo.png" alt="School Logo" class="school-logo">
        <div class="school-name">Cansilayan Farm School</div>
        <form method="POST">
            <select name="user_type" id="user_type" onchange="toggleFields()" required>
                <option value="" disabled selected>Select User Type</option>
                <option value="admin">Admin</option>
                <option value="teacher">Teacher</option>
            </select>

            <!-- Admin Fields -->
            <div id="adminFields" style="display: none;">
                <input type="text" name="username" placeholder="Username">
                <input type="password" name="password" placeholder="Password">
            </div>

            <!-- Teacher Fields -->
            <div id="teacherFields" style="display: none;">
                <input type="text" name="id_number" placeholder="ID Number">
                <input type="text" name="name" placeholder="Full Name">
            </div>

            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
