<?php
session_start();
if (!isset($_SESSION['id_number'])) {
    header("Location: login.php");
    exit();
}

include 'db_connection.php'; // Include your database connection

if (!isset($_GET['id'])) {
    die("Event ID is required.");
}

$event_id = intval($_GET['id']);

// Delete event from database
$query = "DELETE FROM events WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $event_id);

if ($stmt->execute()) {
    echo "<script>alert('Event deleted successfully!'); window.location.href = 'event_dashboard.php';</script>";
} else {
    echo "<script>alert('Error deleting event.'); window.location.href = 'event_dashboard.php';</script>";
}
?>
