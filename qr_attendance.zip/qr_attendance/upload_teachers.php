<?php
require 'vendor/autoload.php'; // Load PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;

session_start();
include 'db_connection.php'; // Database connection

if (!isset($_FILES['excel_file'])) {
    die("Error: No file uploaded. Check your form's file input name.");
}

$file = $_FILES['excel_file']['tmp_name'];
$file_error = $_FILES['excel_file']['error'];

if ($file_error !== 0) {
    die("File upload error! Error code: " . $file_error);
}

if (!$file) {
    die("Please select a file before uploading.");
}

try {
    $spreadsheet = IOFactory::load($file);
    $worksheet = $spreadsheet->getActiveSheet();
    $data = $worksheet->toArray();

    // Skip the header row
    unset($data[0]);

    $stmt = $conn->prepare("INSERT INTO teachers (id_number, name, sex, grade_level, strand) VALUES (?, ?, ?, ?, ?)");

    foreach ($data as $row) {
        $id_number = trim($row[0]);
        $name = trim($row[1]);
        $sex = trim($row[2]);
        $grade_level = intval($row[3]);
        $strand = isset($row[4]) ? trim($row[4]) : null;

        if (empty($id_number) || empty($name) || empty($sex) || empty($grade_level)) {
            echo "Skipping row due to missing required data: " . implode(", ", $row) . "<br>";
            continue;
        }

        $stmt->bind_param("sssis", $id_number, $name, $sex, $grade_level, $strand);
        
        if (!$stmt->execute()) {
            echo "Error inserting row: " . $stmt->error . "<br>";
        }
    }

    $stmt->close();
    $conn->close();

    echo "<script>alert('Excel file imported successfully!'); window.location.href='teacher_adviser.php';</script>";
} catch (Exception $e) {
    die("Error processing file: " . $e->getMessage());
}
?>
