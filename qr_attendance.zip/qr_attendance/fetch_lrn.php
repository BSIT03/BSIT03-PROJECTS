<?php
$conn = new mysqli("localhost", "root", "", "qr_attendance");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST["query"])) {
    $search = "%" . $_POST["query"] . "%";
    $sql = "SELECT lrn FROM students WHERE lrn LIKE ? LIMIT 5";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $search);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        echo "<a href='#' class='list-group-item list-group-item-action suggestion'>" . $row['lrn'] . "</a>";
    }
    $stmt->close();
}
$conn->close();
?>
