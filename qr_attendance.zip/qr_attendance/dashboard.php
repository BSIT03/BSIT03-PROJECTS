<?php
session_start();

// Ensure the user is an admin
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: admin.php"); // Redirect to login page if not logged in as admin
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Cansilayan Farm School</title>
    <!-- Bootstrap & FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        * { font-family: 'Poppins', sans-serif; }
        body { 
            background: url('background.jpg') no-repeat center center fixed; 
            background-size: cover; 
            height: 100vh; 
            display: flex; 
        }
        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            height: 100vh;
            background: rgba(0, 0, 0, 0.85);
            padding: 20px;
            color: #fff;
            position: fixed;
        }
        .sidebar .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar .logo-container img {
            max-width: 100px;
            border-radius: 50%;
        }
        .sidebar h2 {
            color: #FFD700;
            text-align: center;
            margin-bottom: 30px;
            font-size: 22px;
        }
        .sidebar a {
            display: block;
            color: #fff;
            padding: 12px;
            margin: 8px 0;
            text-decoration: none;
            border-radius: 5px;
            transition: 0.3s;
            font-size: 16px;
        }
        .sidebar a:hover {
            background: #FFD700;
            color: #000;
        }
        .sidebar a i {
            margin-right: 10px;
        }

        /* Main Content Styling */
        .content {
            margin-left: 270px; /* Offset for sidebar */
            padding: 40px;
            width: 100%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
        }
        .content h1 {
            font-size: 38px;
            font-weight: bold;
            color: #333;
        }
        .content p {
            font-size: 18px;
            color: #555;
            margin-bottom: 30px;
        }

        /* Card Styling */
        .card-container {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .card {
            background: white;
            border: none;
            color: #333;
            width: 300px;
            padding: 20px;
            text-align: center;
            border-radius: 10px;
            transition: 0.3s;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
        .card:hover {
            background: #f8f9fa;
            transform: translateY(-5px);
        }
        .card i {
            font-size: 40px;
            color: #007bff;
        }
        .card h5 {
            margin-top: 15px;
            font-size: 20px;
            font-weight: bold;
        }
        .btn-custom {
            background: #007bff;
            color: white;
            border-radius: 5px;
            padding: 8px 15px;
            text-decoration: none;
            display: inline-block;
            margin-top: 10px;
            transition: 0.3s;
        }
        .btn-custom:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <div class="logo-container">
        <img src="school_logo.png" alt="School Logo">
    </div>
    <h2>Admin Dashboard</h2>
    <a href="teacher_adviser.php"><i class="fas fa-user-tie"></i> Teacher Adviser</a>
    <a href="student_dashboard.php"><i class="fas fa-users"></i> Students</a>
    <a href="logout.php" class="text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Content Area -->
<div class="content">
    <h1>Welcome, Admin!</h1>
    <p>Manage your users and settings easily.</p>

    <!-- Quick Access Cards -->
    <div class="card-container">
        <div class="card">
            <i class="fas fa-user-tie"></i>
            <h5>Teacher Adviser</h5>
            <a href="teacher_adviser.php" class="btn-custom">View</a>
        </div>
        <div class="card">
            <i class="fas fa-users"></i>
            <h5>Students</h5>
            <a href="student_dashboard.php" class="btn-custom">View</a>
        </div>
    </div>
</div>

</body>
</html>
