<?php
$conn = new mysqli("localhost", "root", "", "qr_attendance");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $name = $_POST['name'];

    // Check if student already attended
    $check = $conn->query("SELECT * FROM attendees WHERE student_id='$student_id'");
    
    if ($check->num_rows == 0) {
        $stmt = $conn->prepare("INSERT INTO attendees (student_id, name) VALUES (?, ?)");
        $stmt->bind_param("ss", $student_id, $name);
        $stmt->execute();
        $stmt->close();

        // Redirect to school_event.php after successful submission
        header("Location: school_event.php");
        exit(); // Ensure no further execution
    } else {
        echo "<h2>You have already marked your attendance.</h2>";
    }
}

$conn->close();
?>

<form method="post">
    <label>Student ID:</label>
    <input type="text" name="student_id" required>
    <label>Name:</label>
    <input type="text" name="name" required>
    <button type="submit">Submit Attendance</button>
</form>
