<?php
session_start();
if (!isset($_SESSION['id_number'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

$grade_level = $_SESSION['grade_level'] ?? 'N/A';
$section = $_SESSION['section'] ?? 'N/A';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            width: 250px;
            background: #343a40;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
            overflow-y: auto;
        }
        .sidebar a {
            padding: 12px;
            display: block;
            color: white;
            text-decoration: none;
            transition: background 0.3s;
        }
        .sidebar a:hover {
            background: #007BFF;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
        }
        .container-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
        .btn-action {
            margin-right: 10px;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h4 class="text-center">Teacher Dashboard</h4>
    <p class="text-center">Grade: <?php echo $grade_level; ?></p>
    <p class="text-center">Section: <?php echo $section; ?></p>
    <a href="#" onclick="fetchStudents()">View Students</a>
    <a href="#" onclick="markAttendance()">Mark Attendance</a>
    <a href="#" onclick="editEvent()">Edit Event</a>
    <a href="logout.php">Logout</a>
</div>

<div class="content">
    <div class="container-box">
        <h2>Student List for Grade <?php echo $grade_level; ?> - Section <?php echo $section; ?></h2>
        <div id="student-data"></div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    fetchStudents();
});

function fetchStudents() {
    fetch("fetch_teacher_students.php")
        .then(response => response.text())
        .then(data => document.getElementById("student-data").innerHTML = data)
        .catch(error => console.error("Error fetching student data:", error));
}

function markAttendance() {
    fetch("fetch_attendance.php")
        .then(response => response.text())
        .then(data => document.getElementById("student-data").innerHTML = data)
        .catch(error => console.error("Error fetching attendance data:", error));
}



function editEvent() {
    window.location.href = "event_dashboard.php";
}

function editEvent() {
    window.location.href = "event_dashboard.php";
}
</script>

</body>
</html>
