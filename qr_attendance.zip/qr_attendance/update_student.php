<?php
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lrn = $_POST['lrn'];
    $full_name = $_POST['full_name'];
    $grade_level = $_POST['grade_level'];
    $section = $_POST['section'] ?: 'N/A'; // Default to 'N/A' if empty
    $strand = $_POST['strand'] ?: 'N/A';  // Default to 'N/A' if empty

    $sql = "UPDATE students SET full_name = ?, grade_level = ?, section = ?, strand = ? WHERE lrn = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $full_name, $grade_level, $section, $strand, $lrn);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }

    $stmt->close();
    $conn->close();
}
?>
