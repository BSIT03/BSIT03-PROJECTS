<?php
session_start();
include 'db_connection.php'; // Ensure the database connection is included

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_id = mysqli_real_escape_string($conn, $_POST['event_id']);
    $lrn = mysqli_real_escape_string($conn, $_POST['lrn']);
    
    // Check if LRN exists in the student database
    $student_check = "SELECT * FROM students WHERE lrn = '$lrn'";
    $student_result = mysqli_query($conn, $student_check);
    
    if (!$student_result) {
        die("Database query failed: " . mysqli_error($conn));
    }

    if (mysqli_num_rows($student_result) > 0) {
        $student = mysqli_fetch_assoc($student_result);
        $grade_level = $student['grade_level'];
        $section = $student['section'];
        $strand = $student['strand'];

        // Check if attendance is already marked
        $attendance_check = "SELECT * FROM attendance WHERE event_id = '$event_id' AND lrn = '$lrn'";
        $attendance_result = mysqli_query($conn, $attendance_check);

        if (!$attendance_result) {
            die("Attendance check failed: " . mysqli_error($conn));
        }

        if (mysqli_num_rows($attendance_result) == 0) {
            // Insert attendance record
            $insert_attendance = "INSERT INTO attendance (event_id, lrn, grade_level, section, strand) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $insert_attendance);
            mysqli_stmt_bind_param($stmt, "sssss", $event_id, $lrn, $grade_level, $section, $strand);
            
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['message'] = "✅ Attendance marked successfully!";
            } else {
                die("Insert attendance failed: " . mysqli_error($conn));
            }

            mysqli_stmt_close($stmt);
        } else {
            $_SESSION['message'] = "⚠️ You have already marked your attendance for this event.";
        }
    } else {
        $_SESSION['message'] = "❌ Invalid LRN. Please enter a valid LRN.";
    }
    
    mysqli_close($conn);
    header("Location: marked_attendance.php?event_id=$event_id");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scan QR Code</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Scan QR Code</h2>
        <?php if (isset($_SESSION['message'])) { ?>
            <div class="alert alert-info text-center">
                <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
            </div>
        <?php } ?>
        <form action="scan_qr.php" method="POST">
            <div class="mb-3">
                <label class="form-label">Event ID (Scanned from QR Code)</label>
                <input type="text" class="form-control" name="event_id" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Enter Your LRN</label>
                <input type="text" class="form-control" name="lrn" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>
