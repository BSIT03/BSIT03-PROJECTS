<?php
include 'db_connection.php';

if (!isset($_GET['event_id'])) {
    echo json_encode(["error" => "Missing event_id parameter"]);
    exit();
}

$event_id = $_GET['event_id'];

// Fetch event details from the database
$sql = "SELECT id, event_name, event_date, event_time FROM events WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();
$event = $result->fetch_assoc();

if ($event) {
    echo json_encode($event);
} else {
    echo json_encode(["error" => "Event not found"]);
}
?>
