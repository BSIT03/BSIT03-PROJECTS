<?php
include 'db_connection.php'; // Make sure your database connection is correct

$name = "John Doe";
$email = "johndoe@example.com";
$password = password_hash("password123", PASSWORD_DEFAULT); // Encrypt password
$role = "adviser";
$grade_level = "Grade 7";

// Prepare SQL statement
$sql = "INSERT INTO teachers (name, email, password, role, grade_level) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $name, $email, $password, $role, $grade_level);

if ($stmt->execute()) {
    echo "Test teacher record added successfully!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
