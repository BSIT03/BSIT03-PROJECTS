<?php
session_start();
if (!isset($_SESSION['id_number'])) {
    header("Location: login.php");
    exit();
}

include 'db_connection.php'; // Include your database connection

if (!isset($_GET['id'])) {
    die("Event ID is required.");
}

$event_id = intval($_GET['id']);

// Fetch event details
$query = "SELECT * FROM events WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();
$event = $result->fetch_assoc();

if (!$event) {
    die("Event not found.");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];
    $event_time = $_POST['event_time'];
    $handled_by = $_POST['handled_by'];

    $update_query = "UPDATE events SET event_name = ?, event_date = ?, event_time = ?, handled_by = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("ssssi", $event_name, $event_date, $event_time, $handled_by, $event_id);

    if ($stmt->execute()) {
        echo "<script>alert('Event updated successfully!'); window.location.href = 'event_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error updating event.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Event</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Event</h2>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Event Name</label>
                <input type="text" class="form-control" name="event_name" value="<?php echo htmlspecialchars($event['event_name']); ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Event Date</label>
                <input type="date" class="form-control" name="event_date" value="<?php echo $event['event_date']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Event Time</label>
                <input type="time" class="form-control" name="event_time" value="<?php echo $event['event_time']; ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Handled By</label>
                <input type="text" class="form-control" name="handled_by" value="<?php echo htmlspecialchars($event['handled_by']); ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Update Event</button>
            <a href="event_dashboard.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
