<?php
$host = "localhost"; // Your database host (usually 'localhost')
$user = "root";      // Your database username
$pass = "";          // Your database password (default is empty for XAMPP)
$dbname = "qr_attendance"; // Your database name

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
