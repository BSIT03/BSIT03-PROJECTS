<?php
$servername = "localhost"; // XAMPP default
$username = "root"; // XAMPP default user
$password = ""; // XAMPP default (leave empty)
$dbname = "qr_attendance"; // ✅ Update this to the correct database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
