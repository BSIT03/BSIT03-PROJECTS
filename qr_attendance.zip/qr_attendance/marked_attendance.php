<?php
include 'db_connection.php'; // Ensure database connection

$query = "SELECT a.student_lrn, s.full_name, e.event_name, a.timestamp
          FROM attendance a
          JOIN students s ON a.student_lrn = s.lrn
          JOIN events e ON a.event_id = e.id
          ORDER BY a.timestamp DESC"; 

$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Records</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Attendance Records</h2>

<table>
    <tr>
        <th>LRN</th>
        <th>Student Name</th>
        <th>Event Name</th>
        <th>Timestamp</th>
    </tr>

    <?php
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['student_lrn'] . "</td>";
        echo "<td>" . $row['full_name'] . "</td>";
        echo "<td>" . $row['event_name'] . "</td>";
        echo "<td>" . $row['timestamp'] . "</td>";
        echo "</tr>";
    }
    ?>
</table>

</body>
</html>
