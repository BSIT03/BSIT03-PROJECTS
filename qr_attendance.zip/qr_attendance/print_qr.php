<?php
require 'phpqrcode/qrlib.php'; // Include phpqrcode library
include 'db_connection.php'; // Include database connection

if (!isset($_GET['id'])) {
    die("Event ID is required.");
}

$event_id = intval($_GET['id']);

// Fetch event details
$query = "SELECT event_name FROM events WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $event_id);
$stmt->execute();
$result = $stmt->get_result();
$event = $result->fetch_assoc();

if (!$event) {
    die("Event not found.");
}

$event_name = $event['event_name'];
$qr_data = "Event: $event_name\nID: $event_id";

// Generate QR Code
$qr_file = "temp_qr.png";
QRcode::png($qr_data, $qr_file, QR_ECLEVEL_L, 10);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print QR Code</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script>
        function printQR() {
            window.print();
        }
    </script>
    <style>
        .print-container {
            text-align: center;
            margin-top: 50px;
        }
    </style>
</head>
<body onload="printQR()">
    <div class="print-container">
        <h2><?php echo htmlspecialchars($event_name); ?></h2>
        <img src="<?php echo $qr_file; ?>" alt="QR Code">
        <p>Event ID: <?php echo $event_id; ?></p>
    </div>
</body>
</html>
