<?php
include 'phpqrcode/qrlib.php'; // Include the phpqrcode library
include 'db_connection.php'; // Include your database connection

if (isset($_GET['data'])) {
    $event_id = intval($_GET['data']);

    // Fetch event details from the database
    $query = "SELECT event_name FROM events WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $event_name = $row['event_name'];

        // Replace with your actual server's IPv4 address
        $server_ip = "1.23";  // Change this to your actual local server IP

        // URL that will be embedded in the QR code
        $qr_data = "http://$server_ip/qr_attendance/scan_qr.php?event_id=" . urlencode($event_id);

        // Generate QR Code
        header('Content-Type: image/png');
        QRcode::png($qr_data, false, QR_ECLEVEL_L, 10);
    } else {
        die("Invalid Event ID");
    }
} else {
    die("No event data provided");
}
?>
