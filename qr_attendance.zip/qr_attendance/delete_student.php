<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qr_attendance";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lrn = $_POST['lrn'] ?? '';

    if (!empty($lrn)) {
        // Prepare SQL delete statement
        $sql = "DELETE FROM students WHERE lrn = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $lrn);

        if ($stmt->execute()) {
            echo "success"; // Send success response
        } else {
            echo "error"; // Send error response
        }

        $stmt->close();
    } else {
        echo "error"; // Error if LRN is empty
    }
}

$conn->close();
?>
