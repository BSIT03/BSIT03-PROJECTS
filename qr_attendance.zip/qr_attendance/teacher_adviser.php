<?php 
session_start();
require 'vendor/autoload.php'; 
include 'db_connection.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin.php");
    exit();
}

// Handle delete functionality
if (isset($_GET['delete']) && ctype_digit($_GET['delete'])) {
    $id_number = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM teachers WHERE id_number = ?");
    $stmt->bind_param("i", $id_number);
    if ($stmt->execute()) {
        echo "<script>alert('Teacher deleted successfully!'); window.location.href='teacher_adviser.php';</script>";
    }
    $stmt->close();
}

// Handle edit functionality (fetch existing teacher data)
$edit_mode = false;
$edit_teacher = [
    'id_number' => '',
    'name' => '',
    'sex' => '',
    'grade_level' => '',
    'section' => '',
    'strand' => ''
];

if (isset($_GET['edit']) && ctype_digit($_GET['edit'])) {
    $edit_mode = true;
    $id_number = intval($_GET['edit']);
    $stmt = $conn->prepare("SELECT * FROM teachers WHERE id_number = ?");
    $stmt->bind_param("i", $id_number);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $edit_teacher = $result->fetch_assoc();
    }
    $stmt->close();
}

// Handle add & update functionality
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_number = intval($_POST['id_number']);
    $name = trim($_POST['name']);
    $sex = strtoupper($_POST['sex']);
    $grade_level = intval($_POST['grade_level']);
    $section = trim($_POST['section']);
    $strand = ($grade_level >= 11 && isset($_POST['strand'])) ? trim($_POST['strand']) : NULL;

    if (isset($_POST['update_teacher'])) {
        $stmt = $conn->prepare("UPDATE teachers SET name = ?, sex = ?, grade_level = ?, section = ?, strand = ? WHERE id_number = ?");
        $stmt->bind_param("ssissi", $name, $sex, $grade_level, $section, $strand, $id_number);
    } else {
        $stmt = $conn->prepare("INSERT INTO teachers (id_number, name, sex, grade_level, section, strand) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ississ", $id_number, $name, $sex, $grade_level, $section, $strand);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Teacher record saved successfully!'); window.location.href='teacher_adviser.php';</script>";
    } else {
        echo "<script>alert('Error saving teacher record.');</script>";
    }
    $stmt->close();
}

// Fetch all teacher advisers
$sql = "SELECT * FROM teachers";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Advisers</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            text-align: center;
            color: black;
            margin: 0;
        }
        .container {
            width: 90%;
            max-width: 900px;
            margin: 40px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.3);
            color: black;
        }
        h2 {
            color: #343a40;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            color: black;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        tr:hover {
            background: #f1f1f1;
        }
        input, select, button {
            width: 95%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            display: block;
        }
        button {
            background: #007bff;
            color: white;
            cursor: pointer;
            border: none;
            padding: 10px;
        }
        button:hover {
            background: #0056b3;
        }
        .actions a {
            text-decoration: none;
            padding: 5px 10px;
            color: white;
            border-radius: 5px;
            margin: 2px;
        }
        .edit {
            background: #28a745;
        }
        .delete {
            background: #dc3545;
        }
        .import-section {
            background: #f8f9fa;
            padding: 15px;
            margin-top: 20px;
            border-radius: 10px;
        }
        .import-section h2 {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="dashboard.php" class="back-button">&larr; Back to Dashboard</a>
        <h2>Teacher Advisers List</h2>
        <table>
            <tr>
                <th>ID Number</th>
                <th>Name</th>
                <th>Sex</th>
                <th>Grade Level</th>
                <th>Section</th>
                <th>Strand</th>
                <th>Actions</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['id_number']) ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['sex']) ?></td>
                    <td><?= htmlspecialchars($row['grade_level']) ?></td>
                    <td><?= htmlspecialchars($row['section']) ?></td>
                    <td><?= htmlspecialchars($row['strand'] ?: 'N/A') ?></td>
                    <td class="actions">
                        <a href="?edit=<?= $row['id_number'] ?>" class="edit">Edit</a>
                        <a href="?delete=<?= $row['id_number'] ?>" class="delete" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>

        <!-- Import Teachers Section -->
        <div class="import-section">
            <h2>Import Teachers</h2>
            <form action="upload_teachers.php" method="POST" enctype="multipart/form-data">
                <input type="file" name="excel_file" accept=".xlsx, .xls" required>
                <button type="submit" name="import">Import</button>
            </form>
        </div>

        <h2><?= $edit_mode ? 'Edit Teacher' : 'Add Teacher' ?></h2>
        <form action="teacher_adviser.php" method="POST">
            <input type="hidden" name="id_number" value="<?= $edit_teacher['id_number'] ?>">
            <input type="text" name="name" placeholder="Full Name" value="<?= $edit_teacher['name'] ?>" required>
            <select name="sex">
                <option value="M" <?= $edit_teacher['sex'] == 'M' ? 'selected' : '' ?>>Male</option>
                <option value="F" <?= $edit_teacher['sex'] == 'F' ? 'selected' : '' ?>>Female</option>
            </select>
            <input type="number" name="grade_level" placeholder="Grade Level" value="<?= $edit_teacher['grade_level'] ?>" required>
            <input type="text" name="section" placeholder="Section" value="<?= $edit_teacher['section'] ?>" required>
            <input type="text" name="strand" placeholder="Strand (For Grade 11-12)" value="<?= $edit_teacher['strand'] ?>">

            <button type="submit" name="<?= $edit_mode ? 'update_teacher' : 'add_teacher' ?>">
                <?= $edit_mode ? 'Update Teacher' : 'Add Teacher' ?>
            </button>
        </form>
    </div>
</body>
</html>
