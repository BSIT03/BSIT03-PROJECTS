<?php
include 'db_connection.php'; // Include database connection

// Get filter parameters from the POST request
$grade_level = $_POST['grade_level'] ?? '';
$section = $_POST['section'] ?? '';
$strand = $_POST['strand'] ?? '';

try {
    // Initialize the SQL query and statement variables
    $sql = '';
    $stmt = null;

    if ($grade_level === '' && $section === '' && $strand === '') {
        // Fetch all students when no filters are applied
        $sql = "SELECT * FROM students";
        $stmt = $conn->prepare($sql);
    } elseif (in_array($grade_level, ['7', '8', '9', '10'])) {
        // Fetch students for Grades 7-10 based on section
        if ($section === '') {
            echo json_encode([]); // No section specified
            exit;
        }
        $sql = "SELECT * FROM students WHERE grade_level = ? AND section = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $grade_level, $section);
    } elseif (in_array($grade_level, ['11', '12'])) {
        // Fetch students for Grades 11-12 based on strand
        if ($strand === '') {
            echo json_encode([]); // No strand specified
            exit;
        }
        $sql = "SELECT * FROM students WHERE grade_level = ? AND strand = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $grade_level, $strand);
    } else {
        // Invalid grade level provided
        echo json_encode([]); // Return an empty array
        exit;
    }

    // Execute the prepared statement
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the data and process it into a clean format
    $students = [];
    $excluded_values = [
        'List and Code of Ind',
        'Indicator',
        'Transferred Out Tra',
        'Generated on Saturd'
    ];
    $column_to_check = 'specific_column_name'; // Replace with the actual column name to check

    while ($row = $result->fetch_assoc()) {
        // Check if the value in the specified column is in the excluded list
        foreach ($row as $column => $value) {
            if (in_array($value, $excluded_values)) {
                // Replace matching values with "N/A"
                $row[$column] = 'N/A';
            }
        }

        // Convert blank fields to "N/A" for consistency
        $row = array_map(function($value) {
            return $value === '' ? 'N/A' : $value;
        }, $row);

        $students[] = $row;
    }

    // Output the student data as JSON
    echo json_encode($students);
} catch (Exception $e) {
    // Log the error for debugging (optional)
    error_log("Error in fetch_student.php: " . $e->getMessage());
    echo json_encode([]); // Return an empty array on failure
} finally {
    // Clean up and close the statement and connection
    if ($stmt) {
        $stmt->close();
    }
    $conn->close();
}
?>
