<?php
session_start();
include 'db_connection.php'; // Ensure this file exists

// Ensure only admin can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin.php");
    exit();
}

if (isset($_GET['id'])) {
    $teacher_id = $_GET['id'];
    
    // Fetch teacher's current data
    $result = $conn->query("SELECT * FROM teachers WHERE id = '$teacher_id' AND role = 'adviser'");
    $teacher = $result->fetch_assoc();
    
    if (!$teacher) {
        echo "<script>alert('Teacher not found!'); window.location.href = 'teacher_adviser.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('No teacher selected'); window.location.href = 'teacher_adviser.php';</script>";
    exit();
}

if (isset($_POST['edit_teacher'])) {
    $teacher_name = $_POST['teacher_name'];
    $teacher_email = $_POST['teacher_email'];
    $teacher_password = !empty($_POST['teacher_password']) ? password_hash($_POST['teacher_password'], PASSWORD_DEFAULT) : $teacher['password'];
    $teacher_grade_level = $_POST['teacher_grade_level'];

    $query = "UPDATE teachers SET name = '$teacher_name', email = '$teacher_email', password = '$teacher_password', grade_level = '$teacher_grade_level' WHERE id = '$teacher_id' AND role = 'adviser'";
    if ($conn->query($query) === TRUE) {
        echo "<script>alert('Teacher updated successfully'); window.location.href = 'teacher_adviser.php';</script>";
    } else {
        echo "<script>alert('Error updating teacher');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Teacher Adviser</title>
</head>
<body>
    <div>
        <h2>Edit Teacher Adviser</h2>
        <form method="POST" action="edit_teacher.php?id=<?= $teacher_id ?>">
            <input type="text" name="teacher_name" value="<?= $teacher['name'] ?>" required>
            <input type="email" name="teacher_email" value="<?= $teacher['email'] ?>" required>
            <input type="password" name="teacher_password" placeholder="New Password (Leave blank to keep current)">
            <input type="text" name="teacher_grade_level" value="<?= $teacher['grade_level'] ?>" required>
            <button type="submit" name="edit_teacher">Update Teacher</button>
        </form>
    </div>
</body>
</html>
