<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qr_attendance";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        .sidebar {
            width: 250px;
            background: #343a40;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
            overflow-y: auto;
        }
        .sidebar a {
            padding: 10px;
            display: block;
            color: white;
            text-decoration: none;
        }
        .sidebar a:hover {
            background: #007BFF;
        }
        .content {
            margin-left: 260px;
            padding: 20px;
        }
        .container-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
        .sub-menu {
            display: none;
            margin-left: 20px;
        }
        .top-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h4 class="text-center">Admin Dashboard</h4>
    <a href="#" onclick="fetchStudents()">All Students</a>

    <a href="#" onclick="toggleSubMenu('grade7')">Grade 7 ▼</a>
    <div id="grade7" class="sub-menu">
        <a href="#" onclick="fetchStudents('7', 'STE')">STE</a>
        <a href="#" onclick="fetchStudents('7', '2')">Section 2</a>
        <a href="#" onclick="fetchStudents('7', '3')">Section 3</a>
        <a href="#" onclick="fetchStudents('7', '4')">Section 4</a>
    </div>

    <a href="#" onclick="toggleSubMenu('grade8')">Grade 8 ▼</a>
    <div id="grade8" class="sub-menu">
        <a href="#" onclick="fetchStudents('8', 'STE')">STE</a>
        <a href="#" onclick="fetchStudents('8', '2')">Section 2</a>
        <a href="#" onclick="fetchStudents('8', '3')">Section 3</a>
        <a href="#" onclick="fetchStudents('8', '4')">Section 4</a>
    </div>

    <a href="#" onclick="toggleSubMenu('grade9')">Grade 9 ▼</a>
    <div id="grade9" class="sub-menu">
        <a href="#" onclick="fetchStudents('9', 'STE')">STE</a>
        <a href="#" onclick="fetchStudents('9', '2')">Section 2</a>
        <a href="#" onclick="fetchStudents('9', '3')">Section 3</a>
        <a href="#" onclick="fetchStudents('9', '4')">Section 4</a>
    </div>

    <a href="#" onclick="toggleSubMenu('grade10')">Grade 10 ▼</a>
    <div id="grade10" class="sub-menu">
        <a href="#" onclick="fetchStudents('10', 'STE')">STE</a>
        <a href="#" onclick="fetchStudents('10', '2')">Section 2</a>
        <a href="#" onclick="fetchStudents('10', '3')">Section 3</a>
        <a href="#" onclick="fetchStudents('10', '4')">Section 4</a>
    </div>

    <a href="#" onclick="toggleSubMenu('grade11')">Grade 11 ▼</a>
    <div id="grade11" class="sub-menu">
        <a href="#" onclick="fetchStudents('11', '', 'OAP')">OAP</a>
        <a href="#" onclick="fetchStudents('11', '', 'Beauty Care')">Beauty Care</a>
        <a href="#" onclick="fetchStudents('11', '', 'CSS')">CSS</a>
        <a href="#" onclick="fetchStudents('11', '', 'STEM')">STEM</a>
    </div>

    <a href="#" onclick="toggleSubMenu('grade12')">Grade 12 ▼</a>
    <div id="grade12" class="sub-menu">
        <a href="#" onclick="fetchStudents('12', '', 'OAP')">OAP</a>
        <a href="#" onclick="fetchStudents('12', '', 'Beauty Care')">Beauty Care</a>
        <a href="#" onclick="fetchStudents('12', '', 'CSS')">CSS</a>
        <a href="#" onclick="fetchStudents('12', '', 'STEM')">STEM</a>
    </div>
</div>

<div class="content">
    <div class="top-buttons">
        <a href="dashboard.php" class="btn btn-primary">&larr; Back to Dashboard</a>
        <form action="import_students.php" method="POST" enctype="multipart/form-data" style="display: inline-block;">
            <input type="file" name="file" required>
            <button type="submit" class="btn btn-success">Import</button>
        </form>
    </div>

    <div class="container-box">
        <h2>Student Dashboard</h2>
        <table>
            <thead>
                <tr>
                    <th>LRN</th>
                    <th>Full Name</th>
                    <th>Grade Level</th>
                    <th>Section</th>
                    <th>Strand</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="student-list">
                <!-- Student data will be loaded here -->
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    fetchStudents(); // Load all students on page load
});

function fetchStudents(gradeLevel = '', section = '', strand = '') {
    $.ajax({
        url: "fetch_student.php",
        type: "POST",
        data: { grade_level: gradeLevel, section: section, strand: strand },
        success: function(response) {
            let students = JSON.parse(response);
            let studentTable = $("#student-list");
            studentTable.html("");

            if (students.length === 0) {
                studentTable.html('<tr><td colspan="6" class="text-center">No students found.</td></tr>');
                return;
            }

            students.forEach(student => {
                studentTable.append(
                    `<tr>
                        <td>${student.lrn}</td>
                        <td>${student.full_name}</td>
                        <td>${student.grade_level}</td>
                        <td>${student.section}</td>
                        <td>${student.strand}</td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="editStudent(${student.lrn})">Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteStudent(${student.lrn})">Delete</button>
                        </td>
                    </tr>`
                );
            });
        }
    });
}

function editStudent(lrn) {
    window.location.href = `edit_student.php?lrn=${lrn}`;
}

function deleteStudent(lrn) {
    if (confirm("Are you sure you want to delete this student?")) {
        $.ajax({
            url: "delete_student.php",
            type: "POST",
            data: { lrn: lrn },
            success: function(response) {
                if (response === "success") {
                    alert("Student deleted successfully.");
                    fetchStudents(); // Refresh the student list
                } else {
                    alert("Failed to delete student.");
                }
            }
        });
    }
}

function toggleSubMenu(id) {
    $("#" + id).toggle();
}
</script>

</body>
</html>
