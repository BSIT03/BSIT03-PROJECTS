<?php
if (extension_loaded('gd')) {
    echo "✅ GD extension is enabled!";
} else {
    echo "❌ GD extension is NOT enabled!";
}
?>
