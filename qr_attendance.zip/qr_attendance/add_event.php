<?php
session_start();
include 'db_connection.php'; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $event_name = mysqli_real_escape_string($conn, $_POST['event_name']);
    $event_date = mysqli_real_escape_string($conn, $_POST['event_date']);
    $event_time = mysqli_real_escape_string($conn, $_POST['event_time']);
    $handled_by = mysqli_real_escape_string($conn, $_POST['handled_by']);

    $query = "INSERT INTO events (event_name, event_date, event_time, handled_by) VALUES (?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssss", $event_name, $event_date, $event_time, $handled_by);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['message'] = "Event added successfully!";
    } else {
        $_SESSION['message'] = "Error adding event: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    header("Location: event_dashboard.php");
    exit();
} else {
    header("Location: event_dashboard.php");
    exit();
}
