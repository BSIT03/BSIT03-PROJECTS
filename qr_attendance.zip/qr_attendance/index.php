<?php
include 'phpqrcode/qrlib.php';

// Define the directory for storing QR codes
$qr_directory = "qrcodes/";
if (!file_exists($qr_directory)) {
    mkdir($qr_directory, 0777, true); // Create folder if it doesn’t exist
}

// Define the URL for attendance
$event_url = "http://192.168.1.31/qr_attendance/attendance.php"; 

// Define QR code file path
$qr_file = $qr_directory . "event_qr.png";

// Generate QR Code
QRcode::png($event_url, $qr_file, QR_ECLEVEL_L, 10);

// Display the QR Code
echo "<h2>Scan this QR Code for Attendance</h2>";
echo "<img src='$qr_file'>";
?>
