<?php
include 'config.php'; // Ensure database connection is included

$grade_level = $_POST['grade_level'] ?? '';
$section = $_POST['section'] ?? '';

if (!$conn) {
    die("Database connection failed: " . $conn->connect_error);
}

// Prepare the SQL statement
$sql = "SELECT * FROM attendance WHERE grade_level = ? AND section = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("r: " . $conn->error); // Debugging SQL issues
}

$stmt->bind_param("ss", $grade_level, $section);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    echo $row['student_name'] . "<br>";
}

$stmt->close();
$conn->close();
?>
