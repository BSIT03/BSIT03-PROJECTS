<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qr_attendance";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

if (!isset($_GET['lrn'])) {
    echo "No LRN provided.";
    exit;
}

$lrn = $_GET['lrn'];

// Fetch the student details
$sql = "SELECT * FROM students WHERE lrn = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $lrn);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

if (!$student) {
    echo "Student not found.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $grade_level = $_POST['grade_level'];
    $section = $_POST['section'];
    $strand = $_POST['strand'];

    // Update student details
    $update_sql = "UPDATE students SET full_name = ?, grade_level = ?, section = ?, strand = ? WHERE lrn = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sssss", $full_name, $grade_level, $section, $strand, $lrn);

    if ($update_stmt->execute()) {
        echo "<script>alert('Student details updated successfully.'); window.location.href = 'student_dashboard.php';</script>";
    } else {
        echo "<script>alert('Failed to update student details.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('background.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
        }
        .container-box {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="container-box">
            <h2>Edit Student Details</h2>
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="lrn" class="form-label">LRN</label>
                    <input type="text" class="form-control" id="lrn" name="lrn" value="<?php echo $student['lrn']; ?>" readonly>
                </div>
                <div class="mb-3">
                    <label for="full_name" class="form-label">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo $student['full_name']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="grade_level" class="form-label">Grade Level</label>
                    <select class="form-control" id="grade_level" name="grade_level" required>
                        <option value="7" <?php echo $student['grade_level'] == '7' ? 'selected' : ''; ?>>Grade 7</option>
                        <option value="8" <?php echo $student['grade_level'] == '8' ? 'selected' : ''; ?>>Grade 8</option>
                        <option value="9" <?php echo $student['grade_level'] == '9' ? 'selected' : ''; ?>>Grade 9</option>
                        <option value="10" <?php echo $student['grade_level'] == '10' ? 'selected' : ''; ?>>Grade 10</option>
                        <option value="11" <?php echo $student['grade_level'] == '11' ? 'selected' : ''; ?>>Grade 11</option>
                        <option value="12" <?php echo $student['grade_level'] == '12' ? 'selected' : ''; ?>>Grade 12</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="section" class="form-label">Section</label>
                    <input type="text" class="form-control" id="section" name="section" value="<?php echo $student['section']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="strand" class="form-label">Strand</label>
                    <input type="text" class="form-control" id="strand" name="strand" value="<?php echo $student['strand']; ?>">
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="student_dashboard.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>
