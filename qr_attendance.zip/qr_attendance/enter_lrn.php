<?php
session_start();
$conn = new mysqli("localhost", "root", "", "qr_attendance");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lrn = trim($_POST['lrn']); // Trim spaces

    if (empty($lrn)) {
        echo "<script>alert('Error: LRN cannot be empty.'); window.location.href='event_lrn.php';</script>";
        exit();
    }

    // Check if LRN exists in the database
    $sql = "SELECT full_name, grade_level, section FROM students WHERE lrn = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Query preparation failed: " . $conn->error);
    }

    $stmt->bind_param("s", $lrn);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();

        // Store student details in session
        $_SESSION['name'] = $student['full_name'];
        $_SESSION['grade'] = $student['grade_level'];
        $_SESSION['section'] = $student['section'];

        // Redirect to school event page
        header("Location: school_event.php");
        exit();
    } else {
        echo "<script>alert('Error: No student found with this LRN.'); window.location.href='event_lrn.php';</script>";
        exit();
    }

    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter LRN</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Enter Your LRN</h2>
        <form method="POST" action="school_event.php">  <!-- ✅ Redirects directly -->
            <div class="mb-3">
                <label for="lrn" class="form-label">LRN:</label>
                <input type="text" class="form-control" id="lrn" name="lrn" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>
