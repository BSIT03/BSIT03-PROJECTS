<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qr_attendance";

// Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

require 'vendor/autoload.php';

// Handle file upload
if (isset($_POST['import'])) {
    if (!isset($_FILES['excel_file']) || $_FILES['excel_file']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['message'] = "File upload error!";
        $_SESSION['message_type'] = "danger";
        header("Location: import_student.php");
        exit();
    }

    $fileTmpName = $_FILES['excel_file']['tmp_name'];

    try {
        // Load Excel file
        $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($fileTmpName);
        $data = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);

        if (empty($data) || count($data) <= 1) {
            $_SESSION['message'] = "The uploaded file is empty or unreadable.";
            $_SESSION['message_type'] = "danger";
            header("Location: import_student.php");
            exit();
        }

        // Prepare SQL statement
        $stmt = $conn->prepare("
            INSERT INTO students (lrn, full_name, grade_level, section, strand) 
            VALUES (?, ?, ?, ?, ?) 
            ON DUPLICATE KEY UPDATE 
            full_name = VALUES(full_name), 
            grade_level = VALUES(grade_level), 
            section = VALUES(section), 
            strand = VALUES(strand)
        ");

        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        // Loop through Excel rows (skip header)
        foreach ($data as $index => $row) {
            if ($index === 1) continue; // Skip header row

            $lrn = !empty(trim($row['A'])) ? trim($row['A']) : 'N/A';
            $full_name = !empty(trim($row['B'])) ? trim($row['B']) : 'N/A';
            $grade_level = !empty(trim($row['C'])) ? trim($row['C']) : 'N/A';
            $section = !empty(trim($row['D'])) ? trim($row['D']) : 'N/A';
            $strand = !empty(trim($row['E'])) ? trim($row['E']) : 'N/A';

            $stmt->bind_param("sssss", $lrn, $full_name, $grade_level, $section, $strand);
            if (!$stmt->execute()) {
                die("Execute failed: " . $stmt->error);
            }
        }

        $_SESSION['message'] = "File successfully uploaded and processed.";
        $_SESSION['message_type'] = "success";
    } catch (Exception $e) {
        $_SESSION['message'] = "Error processing file: " . $e->getMessage();
        $_SESSION['message_type'] = "danger";
    }

    header("Location: import_student.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import Students</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
        }
        form {
            margin-top: 20px;
        }
        input[type="file"] {
            padding: 10px;
        }
        button {
            padding: 10px 20px;
            background-color: blue;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: darkblue;
        }
        .message {
            padding: 10px;
            margin: 10px auto;
            width: 50%;
            border-radius: 5px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .danger {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>

    <h2>Upload Student Excel File</h2>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="message <?= $_SESSION['message_type']; ?>">
            <?= $_SESSION['message']; ?>
        </div>
        <?php unset($_SESSION['message']); unset($_SESSION['message_type']); ?>
    <?php endif; ?>

    <form action="import_student.php" method="POST" enctype="multipart/form-data">
        <input type="file" name="excel_file" accept=".xlsx, .xls" required>
        <button type="submit" name="import">Import</button>
    </form>

</body>
</html>
