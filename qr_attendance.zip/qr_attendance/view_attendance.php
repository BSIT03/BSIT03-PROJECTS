<?php
session_start();
include 'db_connection.php'; // Include database connection

$event_id = isset($_GET['event_id']) ? mysqli_real_escape_string($conn, $_GET['event_id']) : '';

// Fetch event details
$event_query = "SELECT * FROM events WHERE id = '$event_id'";
$event_result = mysqli_query($conn, $event_query);
$event = mysqli_fetch_assoc($event_result);

// Fetch attendance records for the event
$attendance_query = "SELECT students.full_name, students.grade_level, students.section, students.strand FROM attendance 
                    JOIN students ON attendance.lrn = students.lrn 
                    WHERE attendance.event_id = '$event_id'";
$attendance_result = mysqli_query($conn, $attendance_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Attendance</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Attendance for <?php echo $event['event_name']; ?></h2>
        <p class="text-center">Date: <?php echo $event['event_date']; ?> | Time: <?php echo $event['event_time']; ?></p>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Grade Level</th>
                    <th>Section</th>
                    <th>Strand</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($attendance_result)) { ?>
                <tr>
                    <td><?php echo $row['full_name']; ?></td>
                    <td><?php echo $row['grade_level']; ?></td>
                    <td><?php echo $row['section']; ?></td>
                    <td><?php echo ($row['strand'] != '') ? $row['strand'] : 'N/A'; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        <a href="event_dashboard.php" class="btn btn-secondary">Back to Events</a>
    </div>
</body>
</html>

<?php
mysqli_close($conn);
?>
