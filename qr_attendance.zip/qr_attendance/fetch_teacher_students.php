<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qr_attendance";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Ensure teacher is logged in
if (!isset($_SESSION['id_number'])) {
    echo "Unauthorized access!";
    exit();
}

// Get the teacher's assigned grade level and section
$grade_level = $_SESSION['grade_level'] ?? 'N/A';
$section = $_SESSION['section'] ?? 'N/A';

// Fetch students only from the assigned grade level and section
$sql = "SELECT LRN, full_name, grade_level, section, strand FROM students WHERE grade_level = ? AND section = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $grade_level, $section);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<table class='table table-bordered'>
            <thead>
                <tr>
                    <th>LRN</th>
                    <th>Full Name</th>
                    <th>Grade Level</th>
                    <th>Section</th>
                    <th>Strand</th>
                </tr>
            </thead>
            <tbody>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['LRN']}</td>
                <td>{$row['full_name']}</td>
                <td>{$row['grade_level']}</td>
                <td>{$row['section']}</td>
                <td>{$row['strand']}</td>
              </tr>";
    }

    echo "</tbody></table>";
} else {
    echo "<p>No students found for Grade $grade_level - Section $section.</p>";
}

$stmt->close();
$conn->close();
?>
